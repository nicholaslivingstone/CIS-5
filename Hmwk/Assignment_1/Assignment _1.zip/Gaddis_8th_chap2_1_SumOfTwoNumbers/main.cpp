/* 
 * File:   main.cpp
 * Author: Nicholas Livingstone
 * Created on January 7, 2018
 * Purpose:  Stores the Sum of Two Numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int var_1, var_2, total;
    //Initialize Variables
    var_1 = 50;
    var_2 = 100;
    //Process/Map inputs to outputs
            total = var_1 + var_2;
    //Output data
            cout << total;
            //added this line to confirm total value
    //Exit stage right!
    return 0;
}